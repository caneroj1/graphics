//
//  File.h
//  PoolBall
//
//  Created by Joseph Canero on 11/9/13.
//  Copyright (c) 2013 Joseph Canero. All rights reserved.
//

#ifndef __PoolBall__File__
#define __PoolBall__File__

#include <iostream>

#endif /* defined(__PoolBall__File__) */
