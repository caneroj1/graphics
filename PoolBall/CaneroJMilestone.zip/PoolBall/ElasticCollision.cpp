/*  ElasticCollision Implementation File
    CSC350, Final Project
    Created by Joseph Canero
 
    This is the implementation file of the ElasticCollision header and contains definitions of several functions that will be used to ensure realistc motion is achieved for the pool simulator
 */

#include "ElasticCollision.h"

// THESE ARENT BEING USED RIGHT NOW

/*
//function compute the movement of a particular ball
//the movement angle is computed as asin( (abs(y-component))/(magnitude of velocity) )
double calculateTheta(PoolBall Ball) {
    double x = Ball.getXComponent();
    double y = Ball.getYComponent();
    double z = Ball.getZComponent();
    double magnitude = sqrt(pow(x, 2) + pow(y, 2) + pow(z, 2));
    if (magnitude == 0.0) return 0;
    else return asin((std::abs(y))/(magnitude));
    
}

//function to compute the collision angle between two balls
//the collision angle is computed as atan( (y2Loc - y1Loc)/(x2Loc - x1Loc) )
double calculatePhi(PoolBall Ball1, PoolBall Ball2) {
    double dy = (Ball2.getYLocation() - Ball1.getYLocation());
    double dx = (Ball2.getXLocation() - Ball2.getXLocation());
    if (dx == 0.0) return 1.570796326;
    else return atan( dy/dx );
}
*/

void ComputeElasticCollision(PoolBall &Ball1, PoolBall &Ball2) {
    if (Ball1 != Ball2) { //only  do the calculation if the balls colliding are two different objects
        double tempX = .5 * Ball1.getXComponent();
        double tempY = .5 * Ball1.getYComponent();
        Ball1.setXComponent(.5 * tempX + Ball2.getXComponent());
        Ball1.setYComponent(.5 * tempY + Ball2.getYComponent());
        Ball2.setXComponent(tempX);
        Ball2.setYComponent(tempY);
    }
}